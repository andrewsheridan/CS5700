﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SudokuSolver
{
    public class Block : Unit
    {
        public Block(List<char> symbols) : base(symbols) { }
    }
}
