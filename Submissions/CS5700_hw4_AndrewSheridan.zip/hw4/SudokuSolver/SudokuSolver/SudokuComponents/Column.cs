﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SudokuSolver
{
    public class Column : Unit
    {
        public Column(List<char> symbols) : base(symbols) { }
    }
}
