# Person Matcher
## Andrew Sheridan 
## CS 5700

While the actual matching algorithms are quite simple in my implementation, I believe that the abstractions I used are good ones. I wrote tests for a few of the matching algorithms, and included tests for successes and failures of various types (not matches, bad data, etc). A test was also written to ensure the import is working properly. 

**NOTE:** The diagrams have visual paradigm goodness plastered all over them because I had to update VP to get the instructor's examples to pull up correctly. 