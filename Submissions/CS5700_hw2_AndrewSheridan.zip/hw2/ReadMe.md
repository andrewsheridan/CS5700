The IP address of my cloud server is: 54.191.47.218

Due to time constraints, the text panel has alignment issues, which I did not address, due to focusing on other more important elements of the project.